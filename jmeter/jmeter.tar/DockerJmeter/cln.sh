docker stop jmeter
docker rm jmeter
docker rmi jmeter
