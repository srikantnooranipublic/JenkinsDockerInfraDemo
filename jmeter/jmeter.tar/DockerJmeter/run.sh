docker run -d -v /opt/ca/JenkinsPipelineApp/DockerJmeter/JMETER_RUNTIME/:/opt/jmeter  --name=jmeter  --env APP_HOST="10.238.238.40"  --env APP_PORT="8888" jmeter
